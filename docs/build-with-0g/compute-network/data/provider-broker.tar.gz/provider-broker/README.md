# 0G Serving

## Background

The 0G Serving Broker integrates with the 0G Serving Contract to provide a seamless settlement solution for chargeable data retrieval services. For example, if a provider has a chatbot service that can be called using the following command:

```sh
curl https://chatbot.com \
-H "Content-Type: application/json" \
-d '{
     "model": "someModel",
     "messages": [{"role": "user", "content": "Say this is a test!"}],
     "temperature": 0.7
}'
```

To upgrade this service to a chargeable model, the service provider first initiates a local **provider broker** and registers the original service with this broker. Once registered, the broker hosts the service and manages the billing process.

希望使用服务的用户可以使用

## Basic setup

![basic setup](./image/basic-setup.png)

The basic components of serving system includes: provider broker, user broker, and contract.

Provider broker responsibilities:

1. Register, check, update, and delete services
1. Handle incoming requests by:
   1. Verifying and recording requests
   1. Distributing requests to corresponding services
1. Perform settlements using recorded requests as vouchers

User broker responsibilities:

1. Check available services
1. Register, check, deposit, and request refunds to/from provider accounts
1. Handle incoming requests from users by:
   1. Extracting metadata from requests and signing them
   1. Sending the reorganized requests to the provider broker

Contract responsibilities:

1. Store critical variables during the serving process, such as account information (user address, provider address, balance, etc.), and service information (names, URLs, etc.)
1. Include the consensus logic of the serving system, such as:
   1. How to verify request settlements
   1. How to determine the legitimacy of settlement proof (requests)
   1. How users obtain refunds, etc.

Additional explanations:

1. The account mentioned above connects users and providers. Essentially, an account is a storage structure variable in the contract, identifiable by a pair of user and provider addresses. The most important property of an account is its balance, which records the funds available for the user to call the provider's services. In user broker APIs, this is referred to as a provider account because all related accounts share the same user address (set by users in the broker’s configuration) but have different provider addresses. Similarly, in the provider broker, this is referred to as a user account.

1. There is a protocol to determine whether a request is valid. Generally, this involves checking:
   1. Whether the nonce in the request is valid
   1. Whether the service has been modified since the request
   1. Whether the user's account balance is sufficient for payment

When a user broker processes incoming requests, it primarily extracts metadata to prepare for verification. Provider brokers also adhere to this protocol to verify requests. The contract uses this protocol to determine the validity of requests when the provider performs settlements.

## OG Serving Provider Broker Installation

### Prerequisites

- Docker Compose: 1.27+

### Key Commands

1. Provider Starts the Provider Broker:

   1. Copy the file [config](./provider/config.example.yaml) and make the following modifications:

      - Update `servingUrl` to the publicly exposed URL.
      - Update `privateKeys` to the private key of your wallet for the 0G blockchain.

   2. Save the modified file as `./provider/config.local.yaml`.
   3. Start the provider broker

      ```sh
      docker compose -f ./provider/docker-compose.yml up -d

      # It costs around a few minutes to start, the broker will be listening on 127.0.0.1:3080
      ```

2. Provider Registers the Service:

   The serving system now support type of services: LLM inference and 0G Storage. Service type of first one is `chatbot`, and that of the second one is `zgStorage`. In this document, we will use the example of LLM inference services to illustrate.

   1. A service should be prepared, and it should expose an endpoint.

   2. Register the service using provider broker API

   ```sh
   curl -X POST http://127.0.0.1:3080/v1/service \
   -H "Content-Type: application/json" \
   -d '{
           "URL": "<endpoint_of_the_prepared_service>",
           "inputPrice": 100000,
           "outputPrice": 200000,
           "Type": "chatbot",
           "Name": "llama7b"
   }'
   ```

   - `inputPrice` and `outputPrice` have different meanings depending on the service type. For `chatbot`, they represent the cost per token. For `zgStorage`, they are prices per unit of network traffic. The price unit is neuron.

3. Provider Settles the Fee:

   ```sh
   curl -X POST http://127.0.0.1:3080/v1/settle
   ```

   - The provider broker also incorporates an engine that automatically settles fees. This engine follows a specific rule to ensure that all users in debt are charged before their remaining balance becomes insufficient (users can request refunds, but each refund will be temporarily locked). At the same time, it manages the frequency of settlements to avoid incurring excessive gas costs.

### Other API

Please refer [Provider API](./api.html) for more information.
